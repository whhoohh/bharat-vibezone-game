// Lightweight mock AI for demo. Uses simple heuristics to suggest edits.
function suggest(code, ctx){
  const summary = []
  let patch = null

  // If step indicates speed up, look for oxSpeed and increase it
  if(ctx && ctx.step === 0){
    if(/oxSpeed\s*=\s*\d+/.test(code)){
      patch = code.replace(/oxSpeed\s*=\s*(\d+)/, (m, p1)=>`oxSpeed = ${Math.min(15, Number(p1)*3)} // increased by mock AI`)
      summary.push('Increased oxSpeed for a faster run.')
    } else {
      patch = code + '\n// Suggestion: set oxSpeed = 3 for faster movement'
      summary.push('Added oxSpeed variable to speed up ox.')
    }
  } else if(ctx && ctx.step === 1){
    // color change when speed > 3
    if(/drawOx\(ctx\)/.test(code) && /oxSpeed/.test(code)){
      // naive insertion: find drawOx and add color logic
      patch = code.replace(/function drawOx\(ctx\)\s*{/, `function drawOx(ctx) {\n  if(oxSpeed>3) ctx.fillStyle='orange'; else ctx.fillStyle='brown';`)
      summary.push('Added color change when oxSpeed > 3.')
    } else {
      summary.push('Could not find drawOx or oxSpeed; try adding them.')
    }
  } else if(ctx && ctx.step === 2){
    // add jump on spacebar
    if(!/jumpVelocity/.test(code)){
      patch = code + `\nlet jumpVelocity = 0;\nlet onGround = true;\nwindow.addEventListener('keydown', (e)=>{ if(e.code==='Space' && onGround){ jumpVelocity = -8; onGround=false } })\nfunction applyJump(){ if(!onGround){ jumpVelocity += 0.5; /* gravity */ oxY = (typeof oxY==='undefined'?200:oxY) + jumpVelocity; if(oxY>=200){ oxY=200; onGround=true; jumpVelocity=0 } } }\n// call applyJump() inside your loop to apply jump physics`
      summary.push('Added jump variables and a spacebar handler. Call applyJump() in your loop.')
    } else {
      summary.push('Jump logic already exists.')
    }
  } else {
    summary.push('No special suggestions for this step.')
  }

  return { summary: summary.join(' '), patch }
}

export default { suggest }
