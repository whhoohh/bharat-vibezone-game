import React from 'react'
import GuidedWorkflow from './ide/GuidedWorkflow'

export default function App(){
  return (
    <div className="app">
      <header className="topbar">
        <div className="title">Bharat Vibezone — VibeCoding Demo</div>
        <div className="timer" id="demo-timer">10:00</div>
      </header>
      <main className="main">
        <GuidedWorkflow />
      </main>
      <footer className="footer">Mascots: BlackBuck • Muscled Ox • Furious Hen</footer>
    </div>
  )
}
