import React, { useState, useRef, useEffect } from 'react'
import Editor from '@monaco-editor/react'

export default function CodeEditor({ initialCode, onRun, onAskAI }){
  const [code, setCode] = useState(initialCode)
  const editorRef = useRef(null)

  useEffect(()=> setCode(initialCode), [initialCode])

  return (
    <div style={{display:'flex', flexDirection:'column', height:'100%'}}>
      <div style={{flex:1}}>
        <Editor
          height='60vh'
          defaultLanguage='javascript'
          theme='vs-dark'
          value={code}
          onChange={(v)=> setCode(v)}
          onMount={(editor)=> editorRef.current = editor}
        />
      </div>
      <div className="controls">
        <button onClick={()=> onRun(code)}>▶ Run</button>
        <button onClick={async ()=>{
          if(onAskAI){
            const reply = await onAskAI(code)
            if(reply && reply.patch){
              setCode(reply.patch)
            }
          }
        }}>🤖 Ask AI</button>
        <button onClick={()=> {
          // download code as file
          const blob = new Blob([code], {type:'text/javascript'})
          const a = document.createElement('a')
          a.href = URL.createObjectURL(blob)
          a.download = 'vibezone-code.js'
          a.click()
        }}>⬇ Save</button>
      </div>
    </div>
  )
}
