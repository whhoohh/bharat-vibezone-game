import React, { useState, useEffect } from 'react'
import CodeEditor from './CodeEditor'
import mockAI from '../mock/mockAI'

const starterCode = `// Ox movement challenge
let oxX = 50;
let oxSpeed = 1;
function drawOx(ctx) {
  ctx.fillStyle = 'brown';
  ctx.fillRect(oxX, 200, 80, 40); // simple ox block
}
function moveOx() {
  oxX += oxSpeed;
}
// call moveOx() in a loop to animate
`

const steps = [
  'Welcome — speed up the ox. Change oxSpeed to make it run faster.',
  'Make the ox change color when oxSpeed > 3.',
  'Add a jump when spacebar is pressed (y velocity).'
]

export default function GuidedWorkflow(){
  const [step, setStep] = useState(0)
  const [log, setLog] = useState([])
  const [lastRunCode, setLastRunCode] = useState(starterCode)

  useEffect(()=>{
    // simple demo timer (10 minutes) shown in topbar
    const timerEl = document.getElementById('demo-timer')
    let total = 10*60
    const iv = setInterval(()=>{
      total--
      const m = String(Math.floor(total/60)).padStart(2,'0')
      const s = String(total%60).padStart(2,'0')
      if(timerEl) timerEl.textContent = `${m}:${s}`
      if(total<=0) clearInterval(iv)
    },1000)
    return ()=> clearInterval(iv)
  },[])

  const appendLog = (t)=> setLog(l=>[t,...l].slice(0,200))

  const handleRun = (code)=>{
    // For demo, we sandbox run in iframe by creating a blob URL
    setLastRunCode(code)
    appendLog('Ran code — preview updated.')
    // create preview
    const preview = document.getElementById('preview-iframe')
    const html = `
      <html><body style="margin:0; background:#def">
      <canvas id="c" width="600" height="360"></canvas>
      <script>
        try{
          ${code}
          const c = document.getElementById('c')
          const ctx = c.getContext('2d')
          function loop(){
            ctx.clearRect(0,0,c.width,c.height)
            if(typeof moveOx === 'function') moveOx()
            if(typeof drawOx === 'function') drawOx(ctx)
            requestAnimationFrame(loop)
          }
          loop()
        }catch(e){
          document.body.innerHTML = '<pre style="color:red">'+(e.stack||e.message)+'</pre>'
        }
      <\/script></body></html>`
    const blob = new Blob([html],{type:'text/html'})
    const url = URL.createObjectURL(blob)
    if(preview) preview.src = url
  }

  const handleAskAI = async (code)=>{
    appendLog('Asking Bharat AI for suggestions...')
    const reply = await mockAI.suggest(code, {step})
    appendLog('AI: ' + reply.summary)
    if(reply.patch) setLastRunCode(reply.patch)
    return reply
  }

  return (
    <div style={{display:'flex', gap:12, width:'100%'}}>
      <div className="left">
        <div className="step">Step {step+1}: {steps[step]}</div>
        <div className="editor-wrap">
          <CodeEditor initialCode={lastRunCode} onRun={handleRun} onAskAI={handleAskAI} />
        </div>
        <div style={{marginTop:8}}>
          <button onClick={()=>setStep(s=>Math.max(0,s-1))}>Prev</button>
          <button onClick={()=>setStep(s=>Math.min(steps.length-1,s+1))}>Next</button>
        </div>
      </div>
      <div className="right">
        <div style={{height:260, marginBottom:8}}>
          <iframe id="preview-iframe" title="preview" style={{width:'100%', height:'100%', border:'0', borderRadius:6}} />
        </div>
        <div className="mascot">
          <img src="/assets/blackbuck.svg" alt="BlackBuck" onError={(e)=> e.target.style.display='none'} />
          <div>
            <div style={{fontWeight:700}}>BlackBuck (Speed)</div>
            <div style={{fontSize:13, opacity:0.9}}>Tips: Use small increments to test quickly.</div>
          </div>
        </div>
        <div style={{height:8}} />
        <div className="chat-box">
          {log.map((l,i)=> <div key={i} style={{padding:'6px 0', borderBottom:'1px solid rgba(255,255,255,0.03)'}}>{l}</div>)}
        </div>
      </div>
    </div>
  )
}
