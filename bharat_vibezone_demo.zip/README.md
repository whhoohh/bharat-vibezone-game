# Bharat Vibezone — VibeCoding Demo (Front-end only)

## Overview
This is a frontend-only demo that provides a **10-minute guided VibeCoding experience** with a **mock ChatGPT** engine — no API keys required.
It is ready to run on **StackBlitz** or locally with `pnpm`/`npm`.

## Quickstart (StackBlitz)
1. Upload this repo to GitHub or use the local folder.
2. Open in StackBlitz: `https://stackblitz.com/github/<your-user>/<your-repo>`
   - Or drag-and-drop the unzipped folder to StackBlitz.
3. The demo will auto-install dependencies and start instantly.

## Quickstart (Local)
Requirements: Node 18+, pnpm or npm
```bash
# install
pnpm install

# dev
pnpm dev
```

## Notes
- This project uses a **mock AI engine** (`src/mock/mockAI.js`). No OpenAI key is needed.
- To push to a new Git repo:
  ```bash
  git init
  git add .
  git commit -m "Initial Bharat Vibezone demo (mock AI)"
  git branch -M main
  git remote add origin <your-git-url>
  git push -u origin main
  ```
