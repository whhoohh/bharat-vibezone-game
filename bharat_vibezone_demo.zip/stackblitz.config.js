export default {
  installDependencies: true,
  startCommand: "npm run dev",
  openPaths: ["/src/App.jsx"]
}
